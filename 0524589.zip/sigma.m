function y = sigma(a, x)
    y = 1.0 / (1 + exp(-a * x));
end

